# OBS Tracker V3.4.1

- Menu 4 opens a separate, non-blocking live bin list window. You can continue scanning and using the terminal while the list remains open. The list refreshes from saved RZRR data about every 0.6 seconds. Clicking BIN or SEAL copies it. Repeatedly pressing 4 will not create duplicate windows for the same RZRR while the first is open.
- Fixed auto-name counter saving stale settings and resetting the sequential seal roll. A1722589 -> A1722590 -> A1722591.
- PLB random/scannable seals are unchanged; PLS and PLT share the configured sequential roll.

**Back up your `outbound_tracker_data` directory before upgrading.** This build still requires a local desktop Python environment with tkinter for the bin window. Run `py outbound_tracker_v3_4_1.py`.
