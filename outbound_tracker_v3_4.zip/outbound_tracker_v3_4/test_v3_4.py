"""Offline regression checks for V3.4 (fake data only)."""
import builtins
import json
import tempfile
from pathlib import Path
from unittest.mock import patch
import outbound_tracker_v3_4 as a


def scripted_input(*answers):
    return patch.object(builtins, 'input', side_effect=list(answers))


def test():
    with tempfile.TemporaryDirectory() as tmp:
        a.DATA_DIR = Path(tmp)
        a.RZRR_DIR = a.DATA_DIR / 'rzrr'
        a.EXPORT_DIR = a.DATA_DIR / 'exports'
        a.SETTINGS_PATH = a.DATA_DIR / 'settings.json'
        a.RZRR_DIR.mkdir()
        settings = a.load_settings()
        assert a.advance_seal('B17224464') == 'B17224465'
        assert a.advance_seal('B0099') == 'B0100'
        assert a.infer_container_type('PLB29847292') == 'box'
        assert a.infer_container_type('PLS394983') == 'sleeve'
        assert a.infer_container_type('PLT489392') == 'wood'

        # Imported day-shift names: generator should pick up at 4, not 1.
        day = a.RZRRRecord('DAY')
        for i in (1, 2, 3):
            day.bins.append(a.BinRecord(f'PLB/{i}MTL111226', f'S{i}', 0, 'box'))
        day.save()
        assert a.next_persistent_sequence('PLB','MTL','111226',settings) == 4
        assert a.next_persistent_sequence('PLS','MTL','111226',settings) == 1
        a.commit_persistent_sequence('PLB','MTL','111226',5,settings)
        assert a.next_persistent_sequence('PLB','MTL','111226',a.load_settings()) == 6

        # Roll is only consumed when a bin is successfully saved.
        settings=a.load_settings(); settings['seal_roll_next']='B17224464'; a.save_settings(settings)
        night=a.RZRRRecord('NIGHT')
        with scripted_input('PLS394983','A','750'):
            b=a.add_bin(night)
        assert b.seal == 'B17224464' and b.container_type == 'sleeve'
        assert a.load_settings()['seal_roll_next']=='B17224465'
        with scripted_input('PLT489392','A','900'):
            b2=a.add_bin(night)
        assert b2.seal=='B17224465' and b2.container_type=='wood'
        assert a.load_settings()['seal_roll_next']=='B17224466'
        with scripted_input('PLB29847292','RANDOM123','600'):
            b3=a.add_bin(night)
        assert b3.seal=='RANDOM123'
        assert a.load_settings()['seal_roll_next']=='B17224466'

        # Misnamed sleeve corrected to physical box without renaming or requiring weight.
        with scripted_input('PLS394983','','','','B'):
            a.edit_one_bin(night)
        assert night.find_bin('PLS394983').container_type == 'box'
        assert night.floor_positions_required()==2  # two boxes stack, one wood
        assert a.RZRRRecord.load(night.path).find_bin('PLS394983').container_type == 'box'

        # Parity success automatically writes physical scan order.
        dock=a.RZRRRecord('DOCK')
        dock.bins=[a.BinRecord('PLB1','S1',0,'box'),a.BinRecord('PLT2','S2',0,'wood')]
        dock.save()
        # paste lines, blank terminator; scan in reverse order; blank terminator; pause
        with scripted_input('PLB1 - S1','PLT2 - S2','','PLT2','S2','PLB1','S1','',''):
            a.dock_parity_check(dock)
        assert [dock.find_bin(n).dock_order for n in ('PLT2','PLB1')]==[1,2]
        assert dock.state=='dock_staged'
        assert a.RZRRRecord.load(dock.path).find_bin('PLT2').dock_order==1

        # Failed parity leaves prior order unchanged.
        with scripted_input('PLB1 - S1','PLT2 - S2','','PLB1','WRONG','',''):
            a.dock_parity_check(dock)
        assert dock.find_bin('PLT2').dock_order==1

        # Even passing parity doesn't assign orders when tracker lacks records.
        untracked=a.RZRRRecord('UNTRACKED')
        with scripted_input('PLB1 - S1','','PLB1','S1','',''):
            a.dock_parity_check(untracked)
        assert not untracked.bins

    print('ALL V3.4 REGRESSION TESTS PASSED')

if __name__=='__main__':
    test()
