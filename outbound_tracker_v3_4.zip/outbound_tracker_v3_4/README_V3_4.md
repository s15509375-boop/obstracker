# Outbound Tracker V3.4

Offline, standard-library Python prototype. Uses local JSON files. Do not use with actual company information or deploy on a managed company system without appropriate approval.

## Changes

1. **Dock parity → dock/Security order:** When every expected BIN + SEAL pair matches the physical dock scan, the tracker automatically saves that exact scan sequence as dock order. It does not overwrite order on a failed check, a locked RZRR, or when the tracker has not been synchronized with the full expected list. Import the Asana/Issues list into the RZRR first if necessary.
2. **Automatic naming sequence:** When creating `PLB/4MTL111226`, the program checks existing saved RZRRs for imported names `PLB/1MTL111226`, `PLB/2MTL111226`, `PLB/3MTL111226`, plus persistent naming counters. Separate prefixes/material codes/dates have separate sequences. This assumes the existing names follow the generated `PREFIX/[number][material code][MMDDYY]` convention.
3. **Click to copy:** Menu **4 View bins** opens a small window with clickable BIN NAME and SEAL columns; click a value to copy it to your clipboard for eVirtas. Requires a Windows desktop with Tkinter available. If the GUI cannot open, the console fallback offers `N 3` to copy the third bin name or `S 3` for the third seal.
4. **Manual physical container type:** Menu **5 Edit bin** accepts `B` = pallet box, `S` = sleeve, `W` = wood, or Enter to retain current type. The bin's name does not have to change. Corrected physical type is saved and used for floor-space math. A subsequent edit does not silently reset the override.
5. **Sequential seal roll:** Menu **17** configures the **next unused** roll seal (e.g. `B17224464`). On PLS and PLT rapid entry or generated-bin entry, enter `A` at the seal prompt to use the next seal automatically. The next number advances **only after the bin is saved**. You can type any seal manually instead. PLB boxes still accept normal scanned seals. The roll setting persists in `outbound_tracker_data/settings.json`.

## Run

Unzip and run `py outbound_tracker_v3_4.py` from the extracted folder on a computer with Python 3.10+.

## Existing saved RZRRs

V3.4 can open saves from V2, V3, V3.1, V3.2, V3.3, V3.3.1, and V3.3.2. **Back up your `outbound_tracker_data` folder before changing versions.** Keep the data folder next to the V3.4 Python script, or copy the previous data folder into the V3.4 folder if you need your existing records. No cloud sync is included.

## Notes

- Click-to-copy uses the local system clipboard, so consider clipboard handling requirements before use with operational data.
- The roll increments the **trailing numeric suffix**, preserving the leading letters and number width. Verify the roll actually increments by one before using it; don't assume all seal rolls follow that pattern.
- Only successfully matched parity scans automatically replace dock order; the scan order is not changed if there is any mismatch or the saved RZRR records differ from the expected list.
- A type correction clears an existing trailer layout, which must then be rebuilt. This does not delete the RZRR.
