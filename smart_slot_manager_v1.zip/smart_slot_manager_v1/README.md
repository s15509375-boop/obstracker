# Smart Slot Manager V1

Offline Python proof of concept for creating a modular storage map, recording a baseline of the current floor, recommending storage locations, ranking retrieval options by accessibility, reporting usable capacity, and suggesting reorganizations.

## Status

This is a proof of concept, not an approved system of record. Use fabricated data until organizational approval is provided. All recommendations are advisory and must be checked against physical conditions, safety rules, weight limits, and operating procedures.

## Features

- Configurable areas, zones, numbered spots, and A-D height levels
- Example location: `BUFFER-Z1-20A`
- Local SQLite database
- Baseline floor scan
- Fast intake and placement recommendations
- Required build ID, material, container type, weight, priority, and work-area preference
- Pallet boxes up to four high
- Sleeves up to three high
- Wood pallets, racks, and oversized items limited to one level
- Prevents incompatible container types from sharing a vertical stack
- Prevents assigning an upper level when lower configured levels are empty
- Favors heavy inventory lower in a stack
- Favors high-priority inventory at accessible upper levels
- Favors low-priority inventory in deeper storage
- Groups similar materials where practical
- Search ranked by blockers and estimated handling moves
- Capacity dashboard with a 10% reserve estimate
- Reorganization suggestions
- CSV snapshot export
- No network access or third-party packages

## Run

```powershell
py smart_slot_manager.py
```

or:

```powershell
python smart_slot_manager.py
```

The program creates:

```text
smart_slot_data/
├── smart_slot_manager.db
└── exports/
```

## First test

Configure a small zone:

```text
Area: BUFFER
Zone: Z1
Starting spot: 1
Ending spot: 5
Levels: 4
Purpose: general
Allowed types: *
Distance rank: 30
```

Then add MLab storage:

```text
Area: MLAB2
Zone: M
Starting spot: 1
Ending spot: 5
Levels: 4
Purpose: gpu motherboard
Allowed types: pallet_box,sleeve
Distance rank: 10
```

Add fake inventory using **Fast intake + suggestion**. Example:

```text
Build ID: TEST-GPU-001
Description: 28 fake GPUs
Material: GPU
Container type: pallet_box
Weight: 850
Priority: 5
Preferred work area: MLAB
Forecast: today
```

## Scoring logic

The optimizer is transparent and rule-based. It considers:

- preferred work-area match
- location purpose
- distance rank
- priority and accessibility
- compatible existing stacks
- similar nearby material
- weight and stack level
- availability and configured restrictions

Operators can override every suggestion.

## Known limitations

- Single-user local database
- No shared day/night shift synchronization
- No authentication or role permissions
- Distance is represented by a configurable rank, not a measured floor path
- No integration with existing company systems
- DSV or unlabeled aisle inventory must be entered manually to be tracked
- Reorganization suggestions do not produce a complete temporary-move sequence
- Capacity does not account for aisle-clearance, fire-code, or equipment-access rules
- Forecast quality depends on priorities entered by the operator
- The physical floor remains the source of truth

## Security design

- Offline operation
- Standard Python library only
- No networking, telemetry, browser integration, or cloud APIs
- No shell execution
- No administrator privileges
- SQLite transactions and foreign keys
- Unique build IDs
- Fixed application-owned storage directory
- CSV formula-injection protection
- No unsafe serialization such as `pickle`

This prototype has not been formally security reviewed. Do not use real operational data without approval.
