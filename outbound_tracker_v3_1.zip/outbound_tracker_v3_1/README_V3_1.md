# Outbound Shipping Tracker V3.1

Field-focused update to V3.

## Main changes

### Asana / Issues import
Paste previous-shift text as:

`BIN NAME - SEAL`

The tracker imports those pairs into the active RZRR. Because the pasted text does not contain weight or container type, imported records are marked **PENDING**. Their physical details can be completed later with Edit Bin.

This is intended to make day-shift/night-shift handoff useful without inventing missing data.

### True dock parity
Dock parity now uses the pasted Asana / Issues text as the expected source and compares **both bin name and seal** against a fresh physical walk.

Physical workflow:

1. Scan bin.
2. Scan seal.
3. Repeat.

It reports:
- matched pairs
- missing bins
- unexpected/extra bins
- wrong seals
- duplicate physical scans
- duplicate expected entries

A pass requires exact bin+seal parity and exact count parity.

### Always-visible capacity
The main RZRR dashboard calculates capacity directly from the records. You no longer need to build the trailer layout just to know how full the shipment is.

If imported records still have unknown container types, the dashboard shows a conservative **estimated floor-position range** until those details are completed.

### CLI visual refresh
- boxed RZRR dashboard
- live capacity bar
- grouped workflow menu
- cleaner trailer visualization
- pending-detail visibility

### Safety / data integrity
Imported records cannot be auto-laid-out or Security Approved until weight and container type are completed.

## Run

`py outbound_tracker_v3_1.py`

Use fabricated/test data until the workflow is approved for operational data.
