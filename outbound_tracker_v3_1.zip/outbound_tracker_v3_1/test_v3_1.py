import outbound_tracker_v3_1 as app

r = app.RZRRRecord("TEST")
r.bins.append(app.BinRecord("DAYSHIFT-1", "SEAL-1", 0, "unknown"))
assert r.pending_details() == 1
assert r.estimated_floor_range() == (1, 1)

r2 = app.RZRRRecord("FULL")
r2.bins = [app.BinRecord(f"B{i}", f"S{i}", 500, "box") for i in range(48)]
assert r2.floor_positions_required() == 24
for b in r2.bins:
    slot = app.next_slot(r2, b.container_type)
    assert slot
    b.truck_position, b.stack_level = slot
assert all(len(r2.occupied(p)) == 2 for p in app.POSITIONS)
print("PASS")
