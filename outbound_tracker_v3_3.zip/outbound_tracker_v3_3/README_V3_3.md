# Outbound Tracker V3.3

Quick prefix-detection patch.

- PLB = plastic pallet box
- PLS = pallet sleeve
- PLT = regular wood pallet

Imported Asana/Issues `BIN - SEAL` records now infer container type from the bin prefix immediately, so floor-space calculations work without manually entering the type. Weight can remain pending.

Stacking math remains:
- 2 PLB = 1 floor position
- 2 PLS = 1 floor position
- 1 PLT = 1 floor position
- PLB and PLS do not stack together

The auto-name generator now generates PLS names for pallet sleeves.

Run: `py outbound_tracker_v3_3.py`
