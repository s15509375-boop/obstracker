import outbound_tracker_v3_3 as app
assert app.infer_container_type("PLB/1MTL092226") == "box"
assert app.infer_container_type("PLS/1FM092226") == "sleeve"
assert app.infer_container_type("PLT/1CB092226") == "wood"
assert app.infer_container_type("1234") == "unknown"
assert app.container_prefix("box") == "PLB"
assert app.container_prefix("sleeve") == "PLS"
assert app.container_prefix("wood") == "PLT"

r = app.RZRRRecord("IMPORT")
for name, seal in [
    ("PLB/1MTL092226","S1"), ("PLB/2MTL092226","S2"),
    ("PLS/1FM092226","S3"), ("PLS/2FM092226","S4"),
    ("PLT/1CB092226","S5")]:
    r.bins.append(app.BinRecord(name, seal, 0, app.infer_container_type(name)))
assert r.pending_type_count() == 0
assert r.pending_weight_count() == 5
assert r.floor_positions_required() == 3
assert app.parse_expected_line("1234 - 43212") == ("1234", "43212")
print("ALL V3.3 TESTS PASSED")
