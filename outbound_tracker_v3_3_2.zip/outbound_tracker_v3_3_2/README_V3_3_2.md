# V3.3.2 pending-save hotfix

RZRRs with pending weights or unknown imported container details now save and reopen normally. Zero weight means pending; negative weight remains invalid. PLB/PLS/PLT detection is unchanged.
