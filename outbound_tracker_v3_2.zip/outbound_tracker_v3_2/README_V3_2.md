# Outbound Tracker V3.2

V3.2 is the field-test cleanup build.

## Included
- Fixed the V3.1 bin-name edit crash (`BinRecord` unhashable set bug).
- Fixed parity parsing for numeric bin names such as `1234 - 43212`.
- Asana/Issues paste now ends with a blank Enter instead of typing `DONE`.
- Exact parity still compares physical **BIN + SEAL** against pasted expected text.
- 24 standard floor positions are now a **warning/reference**, not a hard data-entry limit.
- Auto-layout can represent non-standard overflow as `O01`, `O02`, etc.
- Default weight warning is **40,000 lb**. It is a warning, not a claim about a legal/operational payload limit.
- Near-full warning begins at 22 known standard floor positions.
- Main dashboard shows floor use, partial BOX/SLEEVE stack room, weight, pending records, and warnings.
- Added **What can still fit?** planning screen. It accounts for partial compatible stacks plus unused standard floor positions.
- Added easy **Delete bin** workflow with confirmation.
- Added persistent, editable material naming schemes.
- Default schemes: Metal=`MTL`, Foam=`FM`, Cardboard=`CB`.
- Plastic pallet box and pallet sleeve names use `PLB`; wood pallets use `PLT`.
- Generated counters persist in `outbound_tracker_data/settings.json`, independently by prefix/material/date.
- Imported Asana/Issues records can remain pending until physical weight/type are known.

## Naming example
For Metal on 09/17/26:
- Plastic pallet box: `PLB/1MTL091726`
- Next PLB Metal container: `PLB/2MTL091726`
- Wood pallet: `PLT/1MTL091726`

PLB and PLT maintain separate counters.

## Important
The 24-position and 40,000-lb values are planning/warning references in this prototype. The tracker intentionally does not block recording physical reality when those values are exceeded. Confirm official operational/load limits separately before treating any threshold as authoritative.

## Run
`py outbound_tracker_v3_2.py`

Keep using fabricated/test data unless operational use is approved.
