import tempfile
from pathlib import Path
import outbound_tracker_v3_2 as app

# Numeric bin names must survive parser.
assert app.parse_expected_line("1234 - 43212") == ("1234", "43212")
assert app.parse_expected_line("1. PLB/1MTL091726 - 555") == ("PLB/1MTL091726", "555")

# Full 48-box standard plan still works.
r = app.RZRRRecord("FULL")
r.bins = [app.BinRecord(f"B{i}", f"S{i}", 500, "box") for i in range(48)]
assert r.floor_positions_required() == 24
for b in r.bins:
    slot = app.next_slot(r, b.container_type)
    assert slot
    b.truck_position, b.stack_level = slot
assert all(len(r.occupied(p)) == 2 for p in app.POSITIONS)

# Over-24 must be accepted by layout math.
r2 = app.RZRRRecord("OVER")
r2.bins = [app.BinRecord(f"W{i}", f"WS{i}", 1000, "wood") for i in range(26)]
assert r2.floor_positions_required() == 26
for b in r2.bins:
    slot = app.next_slot(r2, b.container_type)
    assert slot
    b.truck_position, b.stack_level = slot
assert len([p for p in app.layout_positions(r2) if r2.occupied(p)]) == 26
assert r2.occupied("O01") and r2.occupied("O02")

# Fit math: 45 boxes = 23 floor, one partial box stack, one open floor.
r3 = app.RZRRRecord("FIT")
r3.bins = [app.BinRecord(f"X{i}", f"XS{i}", 500, "box") for i in range(45)]
info = app.trailer_capacity_info(r3)
assert info["known_floor"] == 23
assert info["open_floor"] == 1
assert info["open_box_stack"] == 1
assert info["box_only"] == 3
assert info["sleeve_only"] == 2
assert info["wood_only"] == 1

# Edit duplicate logic should rely on identity, not hashing; basic dataclass is unhashable.
try:
    {r3.bins[0]}
    raise AssertionError("BinRecord unexpectedly hashable")
except TypeError:
    pass

print("ALL V3.2 TESTS PASSED")
