#!/usr/bin/env python3
"""Outbound Shipping Tracker V3.

Offline, standard-library-only command-line prototype.
Designed for test data on a personal computer. Do not use real company data
or transfer it to a managed device without approval.
"""
from __future__ import annotations

import csv
import json
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

APP_VERSION = 3
APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "outbound_tracker_data"
RZRR_DIR = DATA_DIR / "rzrr"
EXPORT_DIR = DATA_DIR / "exports"

POSITIONS = [f"{side}{row:02d}" for row in range(1, 13) for side in ("L", "R")]
TYPES = {
    "box": {"label": "Plastic pallet box", "short": "BOX", "capacity": 2},
    "sleeve": {"label": "Pallet sleeve", "short": "SLV", "capacity": 2},
    "wood": {"label": "Wood pallet", "short": "WOOD", "capacity": 1},
}
STATUSES = ("staged", "dock", "loaded")


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def clean_id(value: str) -> str:
    value = re.sub(r"\s+", " ", value.strip()).upper()
    return value[:100]


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_") or "unnamed"


def pause() -> None:
    input("\nPress Enter to continue...")


def ask_yes_no(prompt: str, default: bool = False) -> bool:
    suffix = " [Y/n]: " if default else " [y/N]: "
    raw = input(prompt + suffix).strip().lower()
    if not raw:
        return default
    return raw in {"y", "yes"}


def choose(prompt: str, options: list[tuple[str, str]], allow_blank: bool = False) -> Optional[str]:
    while True:
        print(f"\n{prompt}")
        for idx, (_, label) in enumerate(options, 1):
            print(f"  {idx}. {label}")
        raw = input("> ").strip()
        if allow_blank and not raw:
            return None
        try:
            return options[int(raw) - 1][0]
        except (ValueError, IndexError):
            print("Choose a valid number.")


def get_weight(prompt: str = "Weight in whole pounds: ") -> int:
    while True:
        raw = input(prompt).strip().replace(",", "")
        try:
            value = int(raw)
            if value <= 0:
                raise ValueError
            return value
        except ValueError:
            print("Enter a positive whole number of pounds.")


def get_aisle(allow_blank: bool = True) -> Optional[int]:
    while True:
        raw = input("OBS aisle (1-4, blank for unassigned): ").strip()
        if allow_blank and not raw:
            return None
        if raw in {"1", "2", "3", "4"}:
            return int(raw)
        print("Enter 1, 2, 3, 4, or leave blank.")


def get_dock() -> Optional[int]:
    while True:
        raw = input("Dock door (1-4, blank if unknown): ").strip()
        if not raw:
            return None
        if raw in {"1", "2", "3", "4"}:
            return int(raw)
        print("Enter 1, 2, 3, 4, or leave blank.")


@dataclass
class BinRecord:
    bin_name: str
    seal: str
    weight_lb: int
    container_type: str
    material: str = ""
    aisle: Optional[int] = None
    status: str = "staged"
    dock_order: Optional[int] = None
    truck_position: Optional[str] = None
    stack_level: Optional[int] = None
    created_at: str = field(default_factory=now_iso)
    updated_at: str = field(default_factory=now_iso)


@dataclass
class RZRRRecord:
    rzrr: str
    dock_door: Optional[int] = None
    state: str = "draft"
    created_at: str = field(default_factory=now_iso)
    updated_at: str = field(default_factory=now_iso)
    bins: list[BinRecord] = field(default_factory=list)
    version: int = APP_VERSION

    @property
    def locked(self) -> bool:
        return self.state in {"security_approved", "complete"}

    @property
    def path(self) -> Path:
        return RZRR_DIR / f"{safe_name(self.rzrr)}.json"

    def save(self) -> None:
        RZRR_DIR.mkdir(parents=True, exist_ok=True)
        self.updated_at = now_iso()
        payload = asdict(self)
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        temp.replace(self.path)

    @classmethod
    def load(cls, path: Path) -> "RZRRRecord":
        raw = json.loads(path.read_text(encoding="utf-8"))
        saved_version = raw.get("version", 2)
        if saved_version not in {2, APP_VERSION}:
            raise ValueError("Unsupported save-file version")
        bins = [BinRecord(**item) for item in raw.pop("bins", [])]
        raw["version"] = APP_VERSION
        obj = cls(**raw)
        obj.bins = bins
        obj.validate()
        return obj

    def validate(self) -> None:
        if not self.rzrr or len(self.rzrr) > 100:
            raise ValueError("Invalid RZRR")
        seen_bins: set[str] = set()
        seen_seals: set[str] = set()
        for item in self.bins:
            if item.container_type not in TYPES:
                raise ValueError("Invalid container type")
            if item.status not in STATUSES:
                raise ValueError("Invalid bin status")
            if item.weight_lb <= 0:
                raise ValueError("Invalid weight")
            b = clean_id(item.bin_name)
            s = clean_id(item.seal)
            if not b or not s or b in seen_bins or s in seen_seals:
                raise ValueError("Duplicate or missing bin/seal")
            seen_bins.add(b)
            seen_seals.add(s)

    def find_bin(self, query: str) -> Optional[BinRecord]:
        q = clean_id(query)
        return next((b for b in self.bins if clean_id(b.bin_name) == q), None)

    def occupied(self, position: str) -> list[BinRecord]:
        return sorted(
            [b for b in self.bins if b.truck_position == position],
            key=lambda b: b.stack_level or 0,
        )

    def floor_positions_required(self) -> int:
        counts = {key: 0 for key in TYPES}
        for b in self.bins:
            counts[b.container_type] += 1
        return counts["wood"] + (counts["box"] + 1) // 2 + (counts["sleeve"] + 1) // 2

    def total_weight(self) -> int:
        return sum(b.weight_lb for b in self.bins)


def list_rzrr_paths() -> list[Path]:
    RZRR_DIR.mkdir(parents=True, exist_ok=True)
    return sorted(RZRR_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)


def create_rzrr() -> RZRRRecord:
    print("\nCREATE RZRR")
    rzrr = clean_id(input("RZRR identifier: "))
    while not rzrr:
        rzrr = clean_id(input("RZRR identifier is required: "))
    record = RZRRRecord(rzrr=rzrr)
    if record.path.exists() and not ask_yes_no("That RZRR exists. Overwrite it?"):
        raise RuntimeError("Cancelled")
    record.save()
    return record


def open_rzrr() -> Optional[RZRRRecord]:
    paths = list_rzrr_paths()
    if not paths:
        print("No saved RZRRs.")
        pause()
        return None
    print("\nSAVED RZRRs")
    loaded: list[tuple[Path, Optional[RZRRRecord]]] = []
    for i, path in enumerate(paths, 1):
        try:
            r = RZRRRecord.load(path)
            loaded.append((path, r))
            print(f"{i:>2}. {r.rzrr:<18} {r.state:<18} {len(r.bins):>3} bins | {r.floor_positions_required():>2}/24 spots")
        except Exception:
            loaded.append((path, None))
            print(f"{i:>2}. {path.name} (invalid save)")
    raw = input("Open number, or blank to cancel: ").strip()
    if not raw:
        return None
    try:
        item = loaded[int(raw) - 1][1]
        if item is None:
            raise ValueError
        return item
    except (ValueError, IndexError):
        print("Invalid selection.")
        pause()
        return None


def add_bin(r: RZRRRecord, previous: Optional[BinRecord] = None) -> Optional[BinRecord]:
    if r.locked:
        print("This RZRR is locked.")
        return None
    print("\nADD BIN (blank bin name cancels)")
    bin_name = clean_id(input("Scan/enter bin name: "))
    if not bin_name:
        return None
    if r.find_bin(bin_name):
        print("That bin already exists in this RZRR.")
        return None
    seal = clean_id(input("Scan/enter seal: "))
    if not seal:
        print("Seal is required.")
        return None
    if any(clean_id(b.seal) == seal for b in r.bins):
        print("That seal is already assigned in this RZRR.")
        return None
    weight = get_weight()

    default_type = previous.container_type if previous else None
    if default_type and ask_yes_no(f"Reuse container type: {TYPES[default_type]['label']}?", default=True):
        ctype = default_type
    else:
        ctype = choose("Container type", [(k, v["label"]) for k, v in TYPES.items()]) or "box"

    # V3 rapid intake deliberately avoids location and contents questions.
    # Legacy fields remain in the save format so V2 records still open.
    material = ""
    aisle = None
    item = BinRecord(bin_name, seal, weight, ctype, material, aisle)
    r.bins.append(item)
    if r.floor_positions_required() > 24:
        r.bins.pop()
        print("Cannot add: this RZRR would exceed 24 trailer floor positions.")
        return None
    r.save()
    print("Saved.")
    return item


def rapid_entry(r: RZRRRecord) -> None:
    previous: Optional[BinRecord] = r.bins[-1] if r.bins else None
    while True:
        item = add_bin(r, previous)
        if item is None:
            break
        previous = item


def show_summary(r: RZRRRecord) -> None:
    counts = {k: 0 for k in TYPES}
    for b in r.bins:
        counts[b.container_type] += 1
    print(f"\n{r.rzrr} — {r.state.replace('_', ' ').title()}")
    print(f"Bins: {len(r.bins)} | Weight: {r.total_weight():,} lb | Floor positions: {r.floor_positions_required()}/24")
    print(f"Boxes: {counts['box']} | Sleeves: {counts['sleeve']} | Wood pallets: {counts['wood']}")
    print(f"Dock door: {r.dock_door if r.dock_door else 'Unassigned'}")
    if r.floor_positions_required() == 24:
        print("Trailer capacity: FULL (24/24 floor positions)")


def list_bins(r: RZRRRecord) -> None:
    show_summary(r)
    print("\n#   BIN NAME                       SEAL                 WT    TYPE   DOCK/TRUCK")
    print("-" * 92)
    for i, b in enumerate(r.bins, 1):
        placement = (
            f"Truck {b.truck_position}/{b.stack_level}" if b.truck_position else
            f"Dock #{b.dock_order}" if b.dock_order is not None else "-"
        )
        print(f"{i:<3} {b.bin_name[:30]:<30} {b.seal[:20]:<20} {b.weight_lb:>5}  {TYPES[b.container_type]['short']:<5}  {placement}")
    pause()


def reset_aisles(r: RZRRRecord) -> None:
    if r.locked:
        print("This RZRR is locked.")
        return
    if ask_yes_no("Clear all current-shift aisle assignments?"):
        for b in r.bins:
            if b.status == "staged":
                b.aisle = None
                b.updated_at = now_iso()
        r.save()
        print("Aisle assignments cleared.")


def assign_rzrr_aisle(r: RZRRRecord) -> None:
    if r.locked:
        print("This RZRR is locked.")
        return
    aisle = get_aisle(allow_blank=False)
    for b in r.bins:
        if b.status == "staged":
            b.aisle = aisle
            b.updated_at = now_iso()
    r.save()
    print(f"All staged bins assigned to Aisle {aisle}.")


def edit_one_bin(r: RZRRRecord) -> None:
    if r.locked:
        print("This RZRR is locked.")
        return
    query = input("Scan/enter bin name to edit: ").strip()
    b = r.find_bin(query)
    if not b:
        print("Bin not found.")
        return

    print("Leave a field blank to keep its value.")
    new_name = clean_id(input(f"Bin name [{b.bin_name}]: "))
    if new_name and r.find_bin(new_name) not in {None, b}:
        print("That bin name already exists; edit cancelled.")
        return

    seal = clean_id(input(f"Seal [{b.seal}]: "))
    if seal and any(clean_id(x.seal) == seal and x is not b for x in r.bins):
        print("Seal already assigned; edit cancelled.")
        return

    raw_weight = input(f"Weight [{b.weight_lb}]: ").strip()
    new_weight = b.weight_lb
    if raw_weight:
        try:
            new_weight = int(raw_weight.replace(",", ""))
            if new_weight <= 0:
                raise ValueError
        except ValueError:
            print("Invalid weight; edit cancelled.")
            return

    old_type = b.container_type
    new_type = old_type
    if ask_yes_no(f"Change container type ({TYPES[old_type]['label']})?"):
        new_type = choose("Container type", [(k, v["label"]) for k, v in TYPES.items()]) or old_type

    # Validate capacity before committing.
    old_values = (b.bin_name, b.seal, b.weight_lb, b.container_type)
    if new_name:
        b.bin_name = new_name
    if seal:
        b.seal = seal
    b.weight_lb = new_weight
    b.container_type = new_type
    if r.floor_positions_required() > 24:
        b.bin_name, b.seal, b.weight_lb, b.container_type = old_values
        print("Edit would exceed trailer capacity; edit cancelled.")
        return

    # Layout can become stale after a name/type edit, so rebuild it explicitly later.
    if new_type != old_type:
        for item in r.bins:
            item.truck_position = None
            item.stack_level = None
            if item.status == "loaded":
                item.status = "dock" if item.dock_order is not None else "staged"
        r.state = "dock_staged" if all(x.dock_order is not None for x in r.bins) else "draft"

    b.updated_at = now_iso()
    r.save()
    print("Updated.")

def next_generated_sequence(r: RZRRRecord, material_code: str, date_code: str) -> int:
    """Find the next PLB sequence for a material/date within this RZRR."""
    material_code = clean_id(material_code).replace(" ", "")
    pattern = re.compile(
        rf"^PLB/(\d+){re.escape(material_code)}{re.escape(date_code)}$",
        re.IGNORECASE,
    )
    used = []
    for b in r.bins:
        compact = b.bin_name.replace(" ", "")
        match = pattern.match(compact)
        if match:
            used.append(int(match.group(1)))
    return max(used, default=0) + 1


def create_named_bin(r: RZRRRecord) -> None:
    """Create a recycling bin that arrives without a pre-existing bin name."""
    if r.locked:
        print("This RZRR is locked.")
        return

    print("\nCREATE / NAME RECYCLING BIN")
    print("Default format: PLB/<sequence><material code><MMDDYY>")
    print("Example on 09/17/26 with plastic code PL: PLB/1PL091726")
    material_code = clean_id(input("Material code (example PL, FM, CB): ")).replace(" ", "")
    if not material_code:
        print("Material code is required.")
        return
    if not re.fullmatch(r"[A-Z0-9]{1,12}", material_code):
        print("Use 1-12 letters/numbers for the material code.")
        return

    date_code = datetime.now().strftime("%m%d%y")
    sequence = next_generated_sequence(r, material_code, date_code)
    generated = f"PLB/{sequence}{material_code}{date_code}"
    print(f"Generated name: {generated}")
    custom = clean_id(input("Press Enter to accept, or type a corrected name: "))
    bin_name = custom or generated

    if r.find_bin(bin_name):
        print("That bin name already exists.")
        return

    seal = clean_id(input("Scan/enter seal: "))
    if not seal:
        print("Seal is required.")
        return
    if any(clean_id(b.seal) == seal for b in r.bins):
        print("That seal is already assigned in this RZRR.")
        return

    weight = get_weight()
    ctype = choose("Container type", [(k, v["label"]) for k, v in TYPES.items()]) or "box"
    item = BinRecord(bin_name, seal, weight, ctype)
    r.bins.append(item)
    if r.floor_positions_required() > 24:
        r.bins.pop()
        print("Cannot add: this RZRR would exceed 24 trailer floor positions.")
        return
    r.save()
    print(f"Saved {bin_name}.")


def parse_expected_line(line: str) -> Optional[tuple[str, Optional[str]]]:
    """Parse common Issues/Asana lines such as '1. BIN - SEAL'."""
    line = line.strip()
    if not line:
        return None
    line = re.sub(r"^\s*\d+\s*[.)-]?\s*", "", line)
    if " - " in line:
        name, seal = line.rsplit(" - ", 1)
        name, seal = clean_id(name), clean_id(seal)
        return (name, seal or None) if name else None
    name = clean_id(line)
    return (name, None) if name else None


def dock_parity_check(r: RZRRRecord) -> None:
    """Compare a fresh physical dock scan with the expected Issues/Asana list."""
    if not r.bins:
        print("No bins entered.")
        return

    print("\nDOCK PARITY CHECK")
    print("Expected source:")
    print("  1. Current RZRR records")
    print("  2. Paste Issues/Asana list (BIN - SEAL)")
    source = input("> ").strip()

    expected: dict[str, Optional[str]] = {}
    if source == "2":
        print("\nPaste expected lines. Type DONE on its own line when finished.")
        while True:
            line = input()
            if line.strip().upper() == "DONE":
                break
            parsed = parse_expected_line(line)
            if parsed:
                name, seal = parsed
                expected[clean_id(name)] = clean_id(seal) if seal else None
    else:
        expected = {clean_id(b.bin_name): clean_id(b.seal) for b in r.bins}

    if not expected:
        print("No expected bins were loaded.")
        return

    print(f"\nExpected bins: {len(expected)}")
    print("Now scan every PHYSICAL bin name on the dock.")
    print("Scanner Enter advances automatically. Blank input finishes.\n")

    physical: list[str] = []
    while True:
        raw = clean_id(input(f"Scan #{len(physical)+1}: "))
        if not raw:
            break
        physical.append(raw)
        status = "OK" if raw in expected else "UNEXPECTED"
        print(f"  {status}: {raw}")

    physical_set = set(physical)
    expected_set = set(expected)
    missing = sorted(expected_set - physical_set)
    unexpected = sorted(physical_set - expected_set)
    duplicates = sorted({x for x in physical if physical.count(x) > 1})

    print("\n" + "=" * 64)
    print("PARITY RESULT")
    print("=" * 64)
    print(f"Expected:   {len(expected_set)}")
    print(f"Scanned:    {len(physical)} ({len(physical_set)} unique)")
    print(f"Missing:    {len(missing)}")
    print(f"Unexpected: {len(unexpected)}")
    print(f"Duplicates: {len(duplicates)}")

    if not missing and not unexpected and not duplicates and len(physical) == len(expected_set):
        print("\nPASS — physical dock bin names match the expected list.")
    else:
        print("\nFAIL — resolve discrepancies before treating the dock as matched.")
        if missing:
            print("\nMISSING FROM PHYSICAL DOCK:")
            for name in missing:
                print(f"  - {name} - {expected.get(name) or 'seal not supplied'}")
        if unexpected:
            print("\nON DOCK BUT NOT EXPECTED:")
            for name in unexpected:
                print(f"  + {name}")
        if duplicates:
            print("\nSCANNED MORE THAN ONCE:")
            for name in duplicates:
                print(f"  ! {name}")
    pause()


def build_dock_order(r: RZRRRecord) -> None:
    if r.locked:
        print("This RZRR is locked.")
        return
    if not r.bins:
        print("No bins entered.")
        return
    print("\nBUILD DOCK ORDER")
    print("Scan bins in the physical order Security should verify them.")
    print("Blank input finishes. Existing dock order will be replaced.")
    for b in r.bins:
        b.dock_order = None
        if b.status == "dock":
            b.status = "staged"
    ordered: list[BinRecord] = []
    while len(ordered) < len(r.bins):
        raw = input(f"Next bin ({len(ordered)+1}/{len(r.bins)}): ").strip()
        if not raw:
            break
        b = r.find_bin(raw)
        if not b:
            print("Not found in this RZRR.")
            continue
        if b in ordered:
            print("Already scanned into dock order.")
            continue
        b.dock_order = len(ordered) + 1
        b.status = "dock"
        b.aisle = None
        b.updated_at = now_iso()
        ordered.append(b)
        print(f"Added #{b.dock_order}: {b.bin_name} - {b.seal}")
    r.state = "dock_staged" if len(ordered) == len(r.bins) else "draft"
    r.save()
    print(f"Dock order saved: {len(ordered)}/{len(r.bins)} bins.")


def issues_lines(r: RZRRRecord) -> list[str]:
    ordered = sorted(r.bins, key=lambda b: (b.dock_order is None, b.dock_order or 999999, b.created_at))
    return [f"{i}. {b.bin_name} - {b.seal}" for i, b in enumerate(ordered, 1)]


def show_issues_output(r: RZRRRecord) -> None:
    print(f"\nISSUES / MOBILITY OUTPUT — {r.rzrr}\n")
    print("\n".join(issues_lines(r)))
    if any(b.dock_order is None for b in r.bins):
        print("\nWARNING: Some bins have no dock order; they appear last.")
    pause()


def export_files(r: RZRRRecord) -> None:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    base = safe_name(r.rzrr)
    text_path = EXPORT_DIR / f"{base}_issues.txt"
    csv_path = EXPORT_DIR / f"{base}_records.csv"
    text_path.write_text("\n".join(issues_lines(r)) + "\n", encoding="utf-8")

    def csv_safe(value: object) -> object:
        if isinstance(value, str) and value[:1] in {"=", "+", "-", "@"}:
            return "'" + value
        return value

    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["rzrr", "bin_name", "seal", "weight_lb", "container_type", "material", "aisle", "status", "dock_order", "truck_position", "stack_level"])
        for b in r.bins:
            writer.writerow([csv_safe(r.rzrr), csv_safe(b.bin_name), csv_safe(b.seal), b.weight_lb, b.container_type, csv_safe(b.material), b.aisle or "", b.status, b.dock_order or "", b.truck_position or "", b.stack_level or ""])
    print(f"Exported:\n  {text_path}\n  {csv_path}")


def next_slot(r: RZRRRecord, ctype: str) -> Optional[tuple[str, int]]:
    """Return the next valid trailer slot.

    V2 checked for an empty floor position before later partial stacks. That
    could consume all 24 floor positions with level-1 boxes and then report
    "full" even though level-2 capacity remained. V3 fills compatible partial
    stacks first, then opens a new floor position.
    """
    cap = TYPES[ctype]["capacity"]

    # Pass 1: fill an existing compatible partial stack.
    if cap > 1:
        for pos in POSITIONS:
            items = r.occupied(pos)
            if items and items[0].container_type == ctype and len(items) < cap:
                used = {b.stack_level for b in items}
                for level in range(1, cap + 1):
                    if level not in used:
                        return pos, level

    # Pass 2: only then consume a new floor position.
    for pos in POSITIONS:
        if not r.occupied(pos):
            return pos, 1
    return None


def auto_layout(r: RZRRRecord) -> None:
    if r.locked:
        print("This RZRR is locked.")
        return
    if r.floor_positions_required() > 24:
        print("This RZRR does not fit on one trailer.")
        return
    for b in r.bins:
        b.truck_position = None
        b.stack_level = None
    ordered = sorted(r.bins, key=lambda b: (b.dock_order is None, b.dock_order or 999999, b.created_at))
    for b in ordered:
        slot = next_slot(r, b.container_type)
        if slot is None:
            print("Unable to create layout.")
            return
        b.truck_position, b.stack_level = slot
        b.status = "loaded"
        b.updated_at = now_iso()
    r.state = "loaded"
    r.save()
    print("Trailer layout created from dock order.")


def show_trailer(r: RZRRRecord) -> None:
    print(f"\nTRAILER — {r.rzrr} (FRONT AT TOP)\n")
    for row in range(1, 13):
        cells = []
        for side in ("L", "R"):
            pos = f"{side}{row:02d}"
            items = r.occupied(pos)
            if not items:
                text = "EMPTY"
            else:
                text = "/".join(f"{TYPES[b.container_type]['short']}:{b.bin_name[:10]}" for b in items)
            cells.append(f"{pos} {text:<30}")
        print(" | ".join(cells))
    print(f"\nFloor positions: {r.floor_positions_required()}/24 | Total weight: {r.total_weight():,} lb")
    pause()


def mark_security_approved(r: RZRRRecord) -> None:
    if r.locked:
        print("Already locked.")
        return
    if not r.bins:
        print("No bins entered.")
        return
    if any(b.dock_order is None for b in r.bins):
        print("Every bin must have a dock order before approval.")
        return
    print("\nThis permanently locks all current data in the prototype.")
    if ask_yes_no("Mark Security Approved?"):
        r.state = "security_approved"
        r.save()
        print("RZRR locked as Security Approved.")


def search_all() -> None:
    query = clean_id(input("Search RZRR or bin name: "))
    if not query:
        return
    results = []
    for path in list_rzrr_paths():
        try:
            r = RZRRRecord.load(path)
        except Exception:
            continue
        if query in clean_id(r.rzrr):
            results.append(f"{r.rzrr}: {len(r.bins)} bins, state={r.state}, dock={r.dock_door or 'unassigned'}")
        for b in r.bins:
            if query in clean_id(b.bin_name):
                loc = f"Dock order {b.dock_order}" if b.status == "dock" else f"Aisle {b.aisle}" if b.aisle else b.status
                results.append(f"{b.bin_name}: {r.rzrr}, {loc}, seal={b.seal}, {b.weight_lb} lb")
    print("\n" + ("\n".join(results) if results else "No matches."))
    pause()


def rzrr_menu(r: RZRRRecord) -> None:
    while True:
        show_summary(r)
        print("\nQUICK WORKFLOW")
        print("1. Rapid scan bins")
        print("2. Create/name recycling bin")
        print("3. View bins")
        print("4. Edit bin (including bin name)")
        print("5. Dock parity check")
        print("6. Build dock/Security order")
        print("7. Show Issues/Mobility text")
        print("8. Auto-build trailer layout")
        print("9. View trailer")
        print("10. Assign/change dock door")
        print("11. Export text and CSV")
        print("12. Mark Security Approved (lock)")
        print("0. Save and return")
        raw = input("> ").strip()
        if raw == "1":
            rapid_entry(r)
        elif raw == "2":
            create_named_bin(r)
        elif raw == "3":
            list_bins(r)
        elif raw == "4":
            edit_one_bin(r)
        elif raw == "5":
            dock_parity_check(r)
        elif raw == "6":
            build_dock_order(r)
        elif raw == "7":
            show_issues_output(r)
        elif raw == "8":
            auto_layout(r)
        elif raw == "9":
            show_trailer(r)
        elif raw == "10":
            if r.locked:
                print("This RZRR is locked.")
            else:
                r.dock_door = get_dock()
                r.save()
        elif raw == "11":
            export_files(r)
        elif raw == "12":
            mark_security_approved(r)
        elif raw == "0":
            r.save()
            return
        else:
            print("Choose a valid option.")

def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    while True:
        print("\nOUTBOUND SHIPPING TRACKER V3")
        print("Offline prototype — use fake/test data only")
        print("\n1. Create RZRR")
        print("2. Open RZRR")
        print("3. Search")
        print("0. Exit")
        raw = input("> ").strip()
        if raw == "1":
            try: rzrr_menu(create_rzrr())
            except RuntimeError as exc: print(exc)
        elif raw == "2":
            r = open_rzrr()
            if r: rzrr_menu(r)
        elif raw == "3": search_all()
        elif raw == "0": return
        else: print("Choose a valid option.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nExited safely.")
