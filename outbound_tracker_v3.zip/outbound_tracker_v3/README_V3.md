# Outbound Shipping Tracker V3

Offline proof-of-concept update based on the V2 field trial.

## V3 changes

- **Faster rapid intake:** normal scanning no longer asks for OBS aisle/location or material/contents.
- **Trailer-full bug fixed:** compatible partial stacks are filled before opening another floor position. This allows a valid load to use all 24 floor positions and, for all stackable boxes/sleeves, up to 48 containers.
- **Editable bin names:** Edit Bin can now correct the bin name, seal, weight, and container type.
- **Create/name recycling bin:** generates names using the default format `PLB/<sequence><material code><MMDDYY>`.
  - Example for plastic on September 17, 2026: `PLB/1PL091726`
  - The generated name is shown before saving and can be manually corrected.
  - Sequence increments for the same material code/date within the RZRR.
- **Dock parity check:** compare a fresh physical dock scan against either:
  - the current RZRR records, or
  - a pasted Issues/Asana-style `BIN - SEAL` list.
  It reports missing, unexpected, and duplicate scans.
- **Simpler menus and bin display.**
- **V2 save compatibility:** V2 JSON records can be opened and are upgraded when saved.

## Still retained

- Required bin name, seal, whole-pound weight, and container type
- Plastic pallet box / pallet sleeve / wood pallet distinction
- Two-high box and sleeve stacking
- Wood pallets occupying one floor position
- 24-position trailer visualization
- Dock/Security order
- Issues/Mobility numbered output
- Security Approved lock
- TXT/CSV exports
- Offline standard-library-only Python

## Run

```powershell
py outbound_tracker_v3.py
```

## Important

This is still a proof of concept. The default generated bin-name format is based on the currently described naming pattern. Confirm the exact official naming convention before relying on generated names operationally.

The parity check currently verifies physical **bin-name presence**. A future version can add a two-scan bin+seal physical verification mode if that matches the actual dock process better.

No network access, cloud API, browser automation, telemetry, or third-party Python packages are used.
