import tempfile
from pathlib import Path
import outbound_tracker_v3 as app

def make(name, ctype):
    return app.BinRecord(name, "S-"+name, 500, ctype)

r = app.RZRRRecord("TEST")
r.bins = [make(f"B{i:02d}", "box") for i in range(1, 49)]
assert r.floor_positions_required() == 24

for b in r.bins:
    slot = app.next_slot(r, b.container_type)
    assert slot is not None, f"No slot for {b.bin_name}"
    b.truck_position, b.stack_level = slot

assert len({b.truck_position for b in r.bins}) == 24
assert all(len(r.occupied(p)) == 2 for p in app.POSITIONS)
print("PASS: 48 boxes fill all 24 floor positions as 24 two-high stacks.")
