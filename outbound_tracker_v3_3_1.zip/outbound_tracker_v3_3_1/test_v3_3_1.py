import outbound_tracker_v3_3_1 as a
cases={"plb29847292":"box","PLB29847292":"box","plt489392":"wood","PLT489392":"wood","pls394983":"sleeve","PLS394983":"sleeve","PLB/1MTL":"box","ABCPLB123":"unknown"}
for n,t in cases.items(): assert a.infer_container_type(n)==t,(n,a.infer_container_type(n),t)
r=a.RZRRRecord("T")
for n in ["PLB111","PLB222","PLS333","PLS444","PLT555"]:
    r.bins.append(a.BinRecord(n,"S"+n,0,a.infer_container_type(n)))
assert r.floor_positions_required()==3
assert r.pending_type_count()==0
print("ALL V3.3.1 PREFIX TESTS PASSED")
