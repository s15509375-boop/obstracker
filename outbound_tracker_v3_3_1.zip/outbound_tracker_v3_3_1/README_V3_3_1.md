# V3.3.1 prefix hotfix

Container type is determined from exactly the first three characters, case-insensitively:

- PLB... = plastic pallet box
- PLS... = pallet sleeve
- PLT... = wooden pallet

No separator is required. This applies to Rapid Bin Entry, Asana/Issues import, generated names, and edited bin names. Unknown prefixes fall back to manual type selection.
